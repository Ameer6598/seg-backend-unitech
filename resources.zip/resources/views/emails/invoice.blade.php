<!DOCTYPE html>
<html>
<head>
    <title>Invoice - Order #{{ $order->order_confirmation_number }}</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .header {
            text-align: center;
            background-color: #f8f8f8;
            padding: 10px;
            border-bottom: 1px solid #ddd;
        }
        .pay-now-btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: #6772e5; /* Stripe brand color */
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
        }
        .pay-now-btn:hover {
            background-color: #5469d4;
        }
        .details-table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        .details-table th, .details-table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        .details-table th {
            background-color: #f8f8f8;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Invoice - Order #{{ $order->order_confirmation_number }}</h1>
        </div>
        <p>Dear {{ $order->billing_address->first_name }} {{ $order->billing_address->last_name }},</p>
        <p>Thank you for your order. Below are the details of your invoice:</p>

        <h2>Billing Address</h2>
        <p>
            {{ $order->billing_address->address }}<br>
            @if($order->billing_address->second_address)
                {{ $order->billing_address->second_address }}<br>
            @endif
            {{ $order->billing_address->city }}, {{ $order->billing_address->state }}, {{ $order->billing_address->country }}<br>
            ZIP: {{ $order->billing_address->zip_postal_code }}<br>
            Phone: {{ $order->billing_address->phone_number }}<br>
            Email: {{ $order->billing_address->email }}
        </p>

        <h2>Order Details</h2>
        <table class VENETIANTEXTILE
            <tr>
                <th>Order ID</th>
                <td>{{ $order->order_confirmation_number }}</td>
            </tr>
            <tr>
                <th>Order Type</th>
                <td>{{ $order->order_type }}</td>
            </tr>
            <tr>
                <th>Product Quantity</th>
                <td>{{ $order->product_quantity }}</td>
            </tr>
            <tr>
                <th>Net Total</th>
                <td>${{ number_format($order->net_total, 2) }}</td>
            </tr>
            <tr>
                <th>Payment Status</th>
                <td>{{ $order->payment_status }}</td>
            </tr>
        </table>

        <h2>Products</h2>
        <table class="details-table">
            <tr>
                <th>Product Name</th>
                <th>SKU</th>
                <th>Manufacturer</th>
            </tr>
            @foreach ($order->product as $product)
                <tr>
                    <td>{{ $product->product_name }}</td>
                    <td>{{ $product->sku }}</td>
                    <td>{{ $product->manufacturer->manufacturer_name ?? 'N/A' }}</td>
                </tr>
            @endforeach
        </table>

        @if($order->payment_status !== 'paid' && $order->stripe_invoice_url)
            <p>
                <a href="{{ $order->stripe_invoice_url }}" class="pay-now-btn">Pay Now</a>
            </p>
        @else
            <p>Payment Status: Paid</p>
        @endif

        <p>Thank you for your business!</p>
    </div>
</body>
</html>