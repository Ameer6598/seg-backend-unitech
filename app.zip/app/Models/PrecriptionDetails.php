<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PrecriptionDetails extends Model
{

protected $table = 'prescription_details';

protected $guarded = [];





}
