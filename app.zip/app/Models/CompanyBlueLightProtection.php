<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CompanyBlueLightProtection extends Model
{


    protected $table = 'company_blue_light_protection_mapper';

    protected $guarded = [];
}
