<?php

namespace App\Models\LensManegment;

use Illuminate\Database\Eloquent\Model;

class LensTint extends Model
{
    protected $table = 'lens_tint';
    protected $guarded = [];
    
}
