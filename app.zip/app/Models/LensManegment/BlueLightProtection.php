<?php

namespace App\Models\LensManegment;

use Illuminate\Database\Eloquent\Model;

class BlueLightProtection extends Model
{
    protected $table = 'blue_light_protection';
    protected $guarded = [];
    
}
