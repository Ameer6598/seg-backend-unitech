<?php

namespace App\Models\LensManegment;

use Illuminate\Database\Eloquent\Model;

class ScracthCoating extends Model
{
    protected $table = 'scracth_coating';
    protected $guarded = [];
    
    
}
