<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CompanyScratchCoatings extends Model
{
    protected $table = 'company_scratch_coating_mapper';

    protected $guarded = [];
}
