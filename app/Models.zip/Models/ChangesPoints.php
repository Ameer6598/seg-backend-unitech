<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ChangesPoints extends Model
{

protected $table = 'order_update_points';

protected $guarded = [];


}
