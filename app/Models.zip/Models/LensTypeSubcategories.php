<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LensTypeSubcategories extends Model
{

  protected $table = 'lens_type_subcategories';
  protected $guarded = [];


}
