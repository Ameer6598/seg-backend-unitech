<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SubadminPermissions extends Model
{

    protected $table = 'subadmin_permissions';
    protected $guarded = [];
}
