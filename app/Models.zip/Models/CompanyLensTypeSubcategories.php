<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CompanyLensTypeSubcategories extends Model
{

    protected $table = 'company_lens_type_subcategories';

    protected $guarded = [];

}
