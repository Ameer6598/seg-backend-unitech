<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EmployeTempOrderdetail extends Model
{
protected $table ='employe_temp_orderdetails';

protected $guarded = [];


}
