<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SegSubadmin extends Model
{
    protected $table = 'seg_subadmin';
    protected $guarded = [];
}
