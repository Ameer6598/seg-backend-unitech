<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BillingAddress extends Model
{

    protected $table = 'order_billing_address';
    protected $guarded = [];
    

}
