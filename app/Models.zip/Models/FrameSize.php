<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FrameSize extends Model
{
    //
    
    protected $table = 'frame_sizes'; 

    protected $guarded = [];
    public $timestamps = false;
    protected $primaryKey = 'frame_size_id'; 


}
