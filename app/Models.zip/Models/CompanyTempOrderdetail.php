<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CompanyTempOrderdetail extends Model
{
protected $table ='company_temp_orderdetails';

protected $guarded = [];
}
