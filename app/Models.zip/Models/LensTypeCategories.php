<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LensTypeCategories extends Model
{

    protected $table = 'lens_type_categories';

     protected $guarded = [];

}
