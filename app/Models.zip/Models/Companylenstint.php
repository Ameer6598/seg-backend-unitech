<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Companylenstint extends Model
{
   protected $table = 'company_lens_tint_mapper'; 

    protected $guarded = [];
    
}
