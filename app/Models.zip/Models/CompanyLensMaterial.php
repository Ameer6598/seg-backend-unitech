<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CompanyLensMaterial extends Model
{
   protected $table = 'company_lens_material_mapper'; 

    protected $guarded = [];
    
}
