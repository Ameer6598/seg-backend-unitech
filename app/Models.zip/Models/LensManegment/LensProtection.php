<?php

namespace App\Models\LensManegment;

use Illuminate\Database\Eloquent\Model;

class LensProtection extends Model
{
    protected $table = 'lens_protection';
    protected $guarded = [];
    
}
