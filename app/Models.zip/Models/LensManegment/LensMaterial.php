<?php

namespace App\Models\LensManegment;

use Illuminate\Database\Eloquent\Model;

class LensMaterial extends Model
{

protected $table = 'lens_material';
protected $guarded = [];



}
